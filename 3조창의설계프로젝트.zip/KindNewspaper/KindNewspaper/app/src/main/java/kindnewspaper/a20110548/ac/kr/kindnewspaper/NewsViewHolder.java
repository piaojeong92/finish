package kindnewspaper.a20110548.ac.kr.kindnewspaper;

import android.widget.TextView;

import com.android.volley.toolbox.NetworkImageView;

//---------------------------------------------------------------------
public class NewsViewHolder {
    TextView txTitle;
    //TextView txContent;
    TextView txAuthor;
    //WebView wvContent;

    NetworkImageView imImage;
}
